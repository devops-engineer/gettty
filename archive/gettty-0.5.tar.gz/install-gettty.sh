#!/bin/sh

echo "source $(brew --prefix)/Homebrew/Library/Taps/rranjan3/homebrew-gettty/gettty" >> ~/.bash_profile
